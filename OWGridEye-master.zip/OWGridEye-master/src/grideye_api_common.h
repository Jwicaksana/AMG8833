/*******************************************************************************
 * Copyright(C) by 2015 Panasonic Corporation.
 ******************************************************************************/
#ifndef	__GRIDEYE_API_COMMON_H
#define	__GRIDEYE_API_COMMON_H


/*******************************************************************************
	type definition
*******************************************************************************/
typedef unsigned char			BOOL;
typedef unsigned char			UCHAR;
typedef unsigned short			USHORT;
typedef unsigned long			ULONG;
typedef signed char				CHAR;


#endif	/* __GRIDEYE_API_COMMON_H */
/*******************************************************************************
 * Copyright(C) by 2015 Panasonic Corporation.
 ******************************************************************************/

