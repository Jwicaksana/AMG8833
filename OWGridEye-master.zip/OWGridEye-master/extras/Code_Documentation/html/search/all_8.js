var searchData=
[
  ['pixel_5fbase_5fadrs',['PIXEL_BASE_ADRS',['../class_o_w_grid_eye.html#a3be3cd1a52c33c6f9f9e7df2b9f4ed50ad1a32f0138cf991e77a572fb0d88a1a5',1,'OWGridEye']]],
  ['power_5fcontrol',['POWER_CONTROL',['../class_o_w_grid_eye.html#a3be3cd1a52c33c6f9f9e7df2b9f4ed50a7cf68b63d7153e4834a8d3c1dcf04087',1,'OWGridEye']]]
];
