var searchData=
[
  ['average',['AVERAGE',['../class_o_w_grid_eye.html#a3be3cd1a52c33c6f9f9e7df2b9f4ed50aa0afcae3935e9885208d7da3e21335b1',1,'OWGridEye']]]
];
