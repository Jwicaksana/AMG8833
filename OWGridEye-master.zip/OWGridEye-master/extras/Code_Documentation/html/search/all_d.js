var searchData=
[
  ['vamg_5fpub_5fimg_5fconvertflipx',['vAMG_PUB_IMG_ConvertFlipX',['../grideye__api__lv2_8c.html#ad140aa18ea5f2bd80628adc5aafd936e',1,'grideye_api_lv2.c']]],
  ['vamg_5fpub_5fimg_5fconvertflipy',['vAMG_PUB_IMG_ConvertFlipY',['../grideye__api__lv2_8c.html#a03dbf0bd189f07fd6febfd1cb7b7a652',1,'grideye_api_lv2.c']]],
  ['vamg_5fpub_5fimg_5fconvertrotate180',['vAMG_PUB_IMG_ConvertRotate180',['../grideye__api__lv2_8c.html#a4df77ad5d092979cdfb4796543003906',1,'grideye_api_lv2.c']]],
  ['vamg_5fpub_5fodt_5fcalcdetectimage1',['vAMG_PUB_ODT_CalcDetectImage1',['../grideye__api__lv2_8c.html#afa7f31d2122c57b98a15dded010d0397',1,'grideye_api_lv2.c']]],
  ['vamg_5fpub_5fodt_5fcalcdetectimage2',['vAMG_PUB_ODT_CalcDetectImage2',['../grideye__api__lv2_8c.html#a3de4ddb4d40a6c5504c5823cfe03f1ab',1,'grideye_api_lv2.c']]],
  ['vamg_5fpub_5fodt_5fcalcdiffimage',['vAMG_PUB_ODT_CalcDiffImage',['../grideye__api__lv2_8c.html#afa0fc38d721be3f1a1394c8a996fb9be',1,'grideye_api_lv2.c']]],
  ['vamg_5fpub_5ftmp_5fconvtemperature64',['vAMG_PUB_TMP_ConvTemperature64',['../grideye__api__lv1_8c.html#a6da75758356612358cb7b90997a6b052',1,'grideye_api_lv1.c']]]
];
