var dir_a978fccf22524bc0e9e0bad66a7adc99 =
[
    [ "DS1920.cpp", "_d_s1920_8cpp.html", "_d_s1920_8cpp" ],
    [ "DS1920.h", "_d_s1920_8h.html", [
      [ "DS1920", "class_one_wire_1_1_d_s1920.html", "class_one_wire_1_1_d_s1920" ]
    ] ]
];