var crc_8h =
[
    [ "calculateCrc16", "crc_8h.html#a951b63031d2aede7556ffab594ca8d9d", null ],
    [ "calculateCrc16", "crc_8h.html#ae03e105c38b55863b18979de119a7413", null ],
    [ "calculateCrc8", "crc_8h.html#a2f29445506630d5310da58c87296056e", null ],
    [ "calculateCrc8", "crc_8h.html#aaef6b74950a819765d9e6d6f59de71cd", null ]
];