var dir_ff66b7d6d6c1058da213c3d1d1ac43ec =
[
    [ "DS2413", "dir_e98ceeb6ced5976915c1c31d2be87863.html", "dir_e98ceeb6ced5976915c1c31d2be87863" ],
    [ "Switches.h", "_switches_8h.html", null ]
];