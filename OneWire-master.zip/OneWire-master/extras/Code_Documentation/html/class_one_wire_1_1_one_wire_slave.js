var class_one_wire_1_1_one_wire_slave =
[
    [ "CmdResult", "class_one_wire_1_1_one_wire_slave.html#a065e628e52a5b530c4a822fd0a94b16e", [
      [ "Success", "class_one_wire_1_1_one_wire_slave.html#a065e628e52a5b530c4a822fd0a94b16ea435421c50dfb49f0ce3aac288de80a9a", null ],
      [ "CommunicationError", "class_one_wire_1_1_one_wire_slave.html#a065e628e52a5b530c4a822fd0a94b16ea05ffc42eb7d1505941340307d275e364", null ],
      [ "CrcError", "class_one_wire_1_1_one_wire_slave.html#a065e628e52a5b530c4a822fd0a94b16ea4c6463da4d5581749a2285360112731f", null ],
      [ "TimeoutError", "class_one_wire_1_1_one_wire_slave.html#a065e628e52a5b530c4a822fd0a94b16eabf1e4e4152e9980ef1d190a30a623bb9", null ],
      [ "OperationFailure", "class_one_wire_1_1_one_wire_slave.html#a065e628e52a5b530c4a822fd0a94b16ea1efb1d9d92ad0bfd42170d96341da877", null ]
    ] ],
    [ "OneWireSlave", "class_one_wire_1_1_one_wire_slave.html#a4698efb604b132c84e92353bcd044893", null ],
    [ "master", "class_one_wire_1_1_one_wire_slave.html#a582aba5f9ef2755cea2cff624e13f216", null ],
    [ "romId", "class_one_wire_1_1_one_wire_slave.html#a4cd52a0a70b354288e9acdd1d0add2fa", null ],
    [ "selectDevice", "class_one_wire_1_1_one_wire_slave.html#ad3aae17edca607dfa95e940302304b58", null ],
    [ "setRomId", "class_one_wire_1_1_one_wire_slave.html#a083eadbe620aa602b628d56e885f99dd", null ]
];