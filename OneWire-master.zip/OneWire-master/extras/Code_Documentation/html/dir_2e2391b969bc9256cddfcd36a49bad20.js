var dir_2e2391b969bc9256cddfcd36a49bad20 =
[
    [ "DS18B20", "dir_5cc8798bdd000363491ba877894b612b.html", "dir_5cc8798bdd000363491ba877894b612b" ],
    [ "DS1920", "dir_8af4f8d594e6e94c203ec94373c60ce3.html", "dir_8af4f8d594e6e94c203ec94373c60ce3" ],
    [ "Sensors.h", "_sensors_8h.html", null ]
];