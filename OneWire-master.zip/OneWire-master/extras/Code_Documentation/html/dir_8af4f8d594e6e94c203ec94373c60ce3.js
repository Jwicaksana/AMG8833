var dir_8af4f8d594e6e94c203ec94373c60ce3 =
[
    [ "DS1920.cpp", "_d_s1920_8cpp.html", "_d_s1920_8cpp" ],
    [ "DS1920.h", "_d_s1920_8h.html", [
      [ "DS1920", "class_one_wire_1_1_d_s1920.html", "class_one_wire_1_1_d_s1920" ]
    ] ]
];