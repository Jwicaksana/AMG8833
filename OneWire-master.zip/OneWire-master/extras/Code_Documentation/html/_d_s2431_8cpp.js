var _d_s2431_8cpp =
[
    [ "DS2431_CMDS", "_d_s2431_8cpp.html#a0278e850bacc90b98cb46de73049577f", [
      [ "WRITE_SCRATCHPAD", "_d_s2431_8cpp.html#a0278e850bacc90b98cb46de73049577fa4bc47e9a7896ab51a7cdf961067b16a3", null ],
      [ "READ_SCRATCHPAD", "_d_s2431_8cpp.html#a0278e850bacc90b98cb46de73049577fa3b66d5a861d08cb8b32618183ca1d0a3", null ],
      [ "COPY_SCRATCHPAD", "_d_s2431_8cpp.html#a0278e850bacc90b98cb46de73049577fad5a7fc0fd76c74994993de7aa166a883", null ],
      [ "READ_MEMORY", "_d_s2431_8cpp.html#a0278e850bacc90b98cb46de73049577fa9c3f0e5bd4515877fc7efa89d715c699", null ]
    ] ]
];