var dir_fdc053c0d31266ee7d6f279a9c1c1616 =
[
    [ "DS2484.cpp", "_d_s2484_8cpp.html", null ],
    [ "DS2484.h", "_d_s2484_8h.html", [
      [ "DS2484", "class_one_wire_1_1_d_s2484.html", "class_one_wire_1_1_d_s2484" ]
    ] ]
];