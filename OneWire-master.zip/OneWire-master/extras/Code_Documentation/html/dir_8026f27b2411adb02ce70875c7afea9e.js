var dir_8026f27b2411adb02ce70875c7afea9e =
[
    [ "DS1920", "dir_a978fccf22524bc0e9e0bad66a7adc99.html", "dir_a978fccf22524bc0e9e0bad66a7adc99" ],
    [ "OneWireTemperature.h", "_one_wire_temperature_8h.html", null ]
];