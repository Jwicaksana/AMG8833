var _d_s1920_8cpp =
[
    [ "DS1920_CMDS", "_d_s1920_8cpp.html#ab888bd9b8213b85f22b9010ca44917fb", [
      [ "WRITE_SCRATCHPAD", "_d_s1920_8cpp.html#ab888bd9b8213b85f22b9010ca44917fba4bc47e9a7896ab51a7cdf961067b16a3", null ],
      [ "READ_SCRATCHPAD", "_d_s1920_8cpp.html#ab888bd9b8213b85f22b9010ca44917fba3b66d5a861d08cb8b32618183ca1d0a3", null ],
      [ "COPY_SCRATCHPAD", "_d_s1920_8cpp.html#ab888bd9b8213b85f22b9010ca44917fbad5a7fc0fd76c74994993de7aa166a883", null ],
      [ "CONV_TEMPERATURE", "_d_s1920_8cpp.html#ab888bd9b8213b85f22b9010ca44917fba75e9cef5f97eca46686498d2d839ce4c", null ],
      [ "RECALL", "_d_s1920_8cpp.html#ab888bd9b8213b85f22b9010ca44917fbabe0acfe102b0cef79ff94d1f56476350", null ]
    ] ]
];