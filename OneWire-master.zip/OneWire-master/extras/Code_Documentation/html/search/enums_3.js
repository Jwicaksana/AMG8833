var searchData=
[
  ['register',['Register',['../class_one_wire_1_1_d_s248x.html#a72e4e151091cd38289003f0d42eed30e',1,'OneWire::DS248x']]],
  ['resolution',['Resolution',['../class_one_wire_1_1_d_s18_b20.html#a168c21d7b131d75777a00b3c3f348193',1,'OneWire::DS18B20']]]
];
