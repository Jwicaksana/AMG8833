var class_one_wire_1_1_d_s1920 =
[
    [ "CmdResult", "class_one_wire_1_1_d_s1920.html#a976162e7ad6471a8f09721acdd1268e5", [
      [ "Success", "class_one_wire_1_1_d_s1920.html#a976162e7ad6471a8f09721acdd1268e5a248badfdc7dd99d4df80c5c6d50d1297", null ],
      [ "CommsReadError", "class_one_wire_1_1_d_s1920.html#a976162e7ad6471a8f09721acdd1268e5a871c3417864ed42e59811def3e9e3d0d", null ],
      [ "CommsWriteError", "class_one_wire_1_1_d_s1920.html#a976162e7ad6471a8f09721acdd1268e5a58b341848ab801fb2d4258b30e2bea89", null ],
      [ "OpFailure", "class_one_wire_1_1_d_s1920.html#a976162e7ad6471a8f09721acdd1268e5acd06f45ea77923644c15e33bd50fbcb8", null ]
    ] ],
    [ "DS1920", "class_one_wire_1_1_d_s1920.html#a3e98a884bf72577dade4dff9ec70d981", null ],
    [ "convertTemperature", "class_one_wire_1_1_d_s1920.html#a4ce6f060d668c994db3f5c8d4819353f", null ],
    [ "copyScratchPad", "class_one_wire_1_1_d_s1920.html#a155aa8c2f9a3ca3cdae7f6d0b22cd32d", null ],
    [ "readScratchPad", "class_one_wire_1_1_d_s1920.html#ab1dd6bb1daa31153de6e6712ec5681fd", null ],
    [ "recallEEPROM", "class_one_wire_1_1_d_s1920.html#a4e6e4d40f47aca5f2bec14adc29db9d7", null ],
    [ "writeScratchPad", "class_one_wire_1_1_d_s1920.html#a6a828b59e6c4387b6d7f70e3b9c4c288", null ]
];