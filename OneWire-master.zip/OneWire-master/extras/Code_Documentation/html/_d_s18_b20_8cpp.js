var _d_s18_b20_8cpp =
[
    [ "DS18B20_CMDS", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739", [
      [ "WRITE_SCRATCHPAD", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739a4bc47e9a7896ab51a7cdf961067b16a3", null ],
      [ "READ_SCRATCHPAD", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739a3b66d5a861d08cb8b32618183ca1d0a3", null ],
      [ "COPY_SCRATCHPAD", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739ad5a7fc0fd76c74994993de7aa166a883", null ],
      [ "CONV_TEMPERATURE", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739a75e9cef5f97eca46686498d2d839ce4c", null ],
      [ "READ_POWER_SUPPY", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739a9660a27b6621498ca384d0e3e3259ecb", null ],
      [ "RECALL", "_d_s18_b20_8cpp.html#ab572ece8a85d1d6698d21f1099007739abe0acfe102b0cef79ff94d1f56476350", null ]
    ] ]
];