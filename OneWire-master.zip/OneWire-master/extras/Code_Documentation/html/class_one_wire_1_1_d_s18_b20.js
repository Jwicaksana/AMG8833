var class_one_wire_1_1_d_s18_b20 =
[
    [ "Resolution", "class_one_wire_1_1_d_s18_b20.html#a168c21d7b131d75777a00b3c3f348193", [
      [ "NINE_BIT", "class_one_wire_1_1_d_s18_b20.html#a168c21d7b131d75777a00b3c3f348193a7c6bfab18b93e41e4c6f3b5b01b67f0e", null ],
      [ "TEN_BIT", "class_one_wire_1_1_d_s18_b20.html#a168c21d7b131d75777a00b3c3f348193aec0b9775fe04a414182afbf9ef48a044", null ],
      [ "ELEVEN_BIT", "class_one_wire_1_1_d_s18_b20.html#a168c21d7b131d75777a00b3c3f348193a099043dff9878cb13355e806bc373e16", null ],
      [ "TWELVE_BIT", "class_one_wire_1_1_d_s18_b20.html#a168c21d7b131d75777a00b3c3f348193ae28c27ee7a9001d49811b0b6b773bffd", null ]
    ] ],
    [ "DS18B20", "class_one_wire_1_1_d_s18_b20.html#a9c65f55160e6f857c5e86dbbd5ff800e", null ],
    [ "convertTemperature", "class_one_wire_1_1_d_s18_b20.html#a116aae5b7b9753bea7129bd6c5cf9a3a", null ],
    [ "copyScratchPad", "class_one_wire_1_1_d_s18_b20.html#acd0121ed2eb666cbd846645b99eccbae", null ],
    [ "readPowerSupply", "class_one_wire_1_1_d_s18_b20.html#a5cea302c5401ce6b90988b265c7d1223", null ],
    [ "readScratchPad", "class_one_wire_1_1_d_s18_b20.html#aef38c678aeb91290c195feefe552f79d", null ],
    [ "recallEEPROM", "class_one_wire_1_1_d_s18_b20.html#a0889650b4ad18e1c8ddeff81a922a599", null ],
    [ "writeScratchPad", "class_one_wire_1_1_d_s18_b20.html#a89e8d62344b8e148cac8d47cd3023a6b", null ]
];